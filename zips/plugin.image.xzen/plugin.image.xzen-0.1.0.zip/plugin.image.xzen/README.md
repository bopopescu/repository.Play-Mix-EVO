XBMC plugin for Zenfolio, available from master XBMC repository.

Supports popular, recent etc., as well as user galleries.

See wiki for full details: http://wiki.xbmc.org/index.php?title=Add-on:XZen
